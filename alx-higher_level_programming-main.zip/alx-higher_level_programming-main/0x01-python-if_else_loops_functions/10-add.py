#!/usr/bin/python3
def add(a, b):
    '''
    Computes the sum of two numbers

    Parameters:
    a (int): The first number
    b (int): The second number
    '''
    return a + b
