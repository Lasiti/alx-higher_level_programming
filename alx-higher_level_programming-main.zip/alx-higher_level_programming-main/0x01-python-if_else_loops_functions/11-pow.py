#!/usr/bin/python3
def pow(a, b):
    '''
    Computes the exponent of a number

    Parameters:
    a (int | float): The base number
    b (int | float): The exponent
    '''
    return a ** b
