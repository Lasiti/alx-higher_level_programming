'use strict';
$(() => {
  $('header').css('color', '#FF0000');
});
