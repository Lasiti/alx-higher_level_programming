'use strict';
window.addEventListener('load', () => {
  document.querySelector('header').style.color = '#FF0000';
});
