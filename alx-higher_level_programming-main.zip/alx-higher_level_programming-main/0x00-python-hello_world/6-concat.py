#!/usr/bin/python3
str1 = "Holberton"
str2 = "School"
str1 = "{} {}".format(str1, str2)
print("Welcome to {}!".format(str1))
