#!/usr/bin/python3
'''A module for working with geometry.
'''


class BaseGeometry:
    '''The base class for all geometry objects.
    '''
    pass
