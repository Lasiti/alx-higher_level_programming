#!/usr/bin/python3
"""A module for working with squares.
"""


class Square:
    """Represents a 2D Polygon with 4 equal and perpendicular sides.
    """
    pass
