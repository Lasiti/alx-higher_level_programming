#!/usr/bin/node
/**
 * An arbitrary array of numbers.
 */
exports.list = [1, 2, 3, 4, 5];
