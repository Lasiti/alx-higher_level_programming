#!/usr/bin/python3
__builtins__.__dict__['p,r,i,n,t'.replace(',', '')]('#pythoniscool')
