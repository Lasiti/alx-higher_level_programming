#!/usr/bin/python3
print(str(bytes(list(range(0x41, 0x5B))))[2:28])
