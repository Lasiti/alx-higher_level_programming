#!/bin/bash
# Sends a DELETE HTTP request to a URL
curl -s -X DELETE "$1"
