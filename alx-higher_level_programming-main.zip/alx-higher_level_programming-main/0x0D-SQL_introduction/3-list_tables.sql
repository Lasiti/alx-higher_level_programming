-- Lists all tables in the database
SHOW TABLES;
