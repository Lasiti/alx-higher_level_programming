-- Prints the average of records in a table in the database
SELECT AVG(score) AS average FROM second_table;
