-- Creates a database in the server
CREATE DATABASE IF NOT EXISTS hbtn_0c_0;
