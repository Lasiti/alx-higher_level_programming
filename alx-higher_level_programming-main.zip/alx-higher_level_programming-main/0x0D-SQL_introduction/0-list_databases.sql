-- Lists all databases in the server
SHOW DATABASES;
