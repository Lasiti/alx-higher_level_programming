-- Inserts a record in a table in the database
INSERT INTO first_table VALUES (89, 'Best School');
