-- Deletes records in a table in the database
DELETE FROM second_table
    WHERE score <= 5;
