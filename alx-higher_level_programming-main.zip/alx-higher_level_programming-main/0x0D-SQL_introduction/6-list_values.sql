-- Lists all rows in a table in the database
SELECT * FROM first_table;
