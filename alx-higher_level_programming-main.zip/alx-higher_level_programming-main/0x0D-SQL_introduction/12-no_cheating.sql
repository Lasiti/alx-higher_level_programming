-- Changes records in a table in the database
UPDATE second_table
    SET score = 10
    WHERE name = 'Bob';
