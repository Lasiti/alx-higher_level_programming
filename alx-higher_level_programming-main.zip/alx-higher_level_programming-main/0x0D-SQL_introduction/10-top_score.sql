-- Sorts records in a table in the database
SELECT score, name
    FROM second_table
    ORDER BY score DESC;
