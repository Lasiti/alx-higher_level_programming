-- Sorts and filters records in a table in the database
SELECT score, name
    FROM second_table
    WHERE score >= 10
    ORDER BY score DESC;
