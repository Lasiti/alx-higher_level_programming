-- Deletes a database in the server
DROP DATABASE IF EXISTS hbtn_0c_0;
