-- Counts records that pass a condition in a table in the database
SELECT COUNT(*) FROM first_table WHERE id = 89;
