-- Prints the full description of a table in the database
SHOW CREATE TABLE first_table;
