#!/usr/bin/python3
"""Classes for working with polygon models.
"""
