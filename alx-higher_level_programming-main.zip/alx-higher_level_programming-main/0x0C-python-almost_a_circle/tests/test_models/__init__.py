#!/usr/bin/python3
"""Tests for the polygon models.
"""
