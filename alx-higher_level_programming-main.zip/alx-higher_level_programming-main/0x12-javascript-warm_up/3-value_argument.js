#!/usr/bin/node
const arg0 = process.argv[2];

console.log(arg0 !== undefined ? arg0 : 'No argument');
