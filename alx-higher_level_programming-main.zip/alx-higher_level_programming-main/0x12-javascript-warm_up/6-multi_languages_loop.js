#!/usr/bin/node
const texts = [
  'C is fun',
  'Python is cool',
  'JavaScript is amazing'
];

for (let i = 0; i < texts.length; i++) {
  console.log(texts[i]);
}
