#!/usr/bin/node
['C is fun', 'Python is cool', 'JavaScript is amazing'].forEach(
  elem => console.log(elem)
);
